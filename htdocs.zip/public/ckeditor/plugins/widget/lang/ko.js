/**
 * @license Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'widget', 'ko', {
	'move': '움직이려면 클릭 후 드래그 하세요',
	'label': '%1 위젯'
} );
