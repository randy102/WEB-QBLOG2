CKEDITOR.plugins.setLang("pbckcode", "fr",
  {
    title: 'PBCKCODE',
    addCode: 'Ajouter du code',
    editCode: 'Modifier ce code',
    editor: 'Editeur',
    settings: 'Réglages',
    mode: 'Langage',
    tabSize: 'Indentation',
    theme: 'Theme',
    softTab: 'Enable soft tabs',
    emmet: 'Activer Emmet'
  });
