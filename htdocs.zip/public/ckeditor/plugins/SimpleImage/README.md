ckeditor-simple-image-plugin
============================

A simple plugin to add an image for CKEditor
